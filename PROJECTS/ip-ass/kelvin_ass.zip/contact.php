<?php

require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php#contact");
    exit;
}

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$subject = trim($_POST["subject"] ?? "");
$message = trim($_POST["message"] ?? "");

if ($name === "" || $email === "" || $subject === "" || $message === "") {
    header("Location: index.php?status=empty#contact");
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: index.php?status=invalid_email#contact");
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO contact_messages (name, email, subject, message)
     VALUES (?, ?, ?, ?)"
);

if (!$stmt) {
    header("Location: index.php?status=error#contact");
    exit;
}

$stmt->bind_param("ssss", $name, $email, $subject, $message);

if ($stmt->execute()) {

    /*
     * Optional email notification.
     *
     * Database storage works immediately with XAMPP.
     * PHP mail() requires SMTP configuration in XAMPP
     * if you want an actual notification email.
     */
    $to = "rjmkelvin@gamil.com";
    $mailSubject = "New Portfolio Message: " . $subject;

    $mailBody =
        "New message received from your portfolio.\n\n" .
        "Name: " . $name . "\n" .
        "Email: " . $email . "\n" .
        "Subject: " . $subject . "\n\n" .
        "Message:\n" . $message;

    $headers = "From: portfolio@localhost\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";

    @mail($to, $mailSubject, $mailBody, $headers);

    $stmt->close();
    $conn->close();

    header("Location: index.php?status=success#contact");
    exit;
}

$stmt->close();
$conn->close();

header("Location: index.php?status=error#contact");
exit;

?>
