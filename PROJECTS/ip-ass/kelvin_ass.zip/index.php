<?php
$status = $_GET['status'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maria Kelvin R. | Portfolio</title>
<meta name="description" content="Maria Kelvin R. - Engineering Student and Developer Portfolio">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
  <div class="container nav-container">
    <a href="#home" class="logo">Maria <span>Kelvin</span></a>
    <button class="menu-btn" id="menuBtn">☰</button>
    <nav id="nav">
      <a href="#home">Home</a>
      <a href="#about">About</a>
      <a href="#skills">Skills</a>
      <a href="#projects">Projects</a>
      <a href="#education">Education</a>
      <a href="#contact">Contact</a>
    </nav>
  </div>
</header>

<main>

<section class="hero" id="home">
  <div class="container hero-grid">
    <div>
      <span class="badge">Engineering Student • Developer</span>
      <h1>Hello, I'm <span>Maria Kelvin R.</span></h1>
      <p>
        I am an engineering student interested in web development, software
        projects, databases and practical technology solutions. I enjoy
        turning ideas into clean, useful and responsive applications.
      </p>
      <div class="buttons">
        <a href="#projects" class="btn primary">View Projects</a>
        <a href="#contact" class="btn secondary">Contact Me</a>
      </div>
    </div>

    <div class="profile-card">
      <div class="avatar">MK</div>
      <h2>Maria Kelvin R.</h2>
      <p>Student Developer</p>
    </div>
  </div>
</section>

<section id="about">
  <div class="container">
    <div class="section-heading">
      <span>ABOUT ME</span>
      <h2>Building skills through projects</h2>
      <p>Focused on learning modern development technologies and creating practical solutions.</p>
    </div>

    <div class="two-column">
      <div class="card">
        <h3>Who I Am</h3>
        <p>
          I am an engineering student with an interest in full-stack development,
          application design and database-driven systems. I learn by building
          projects and improving their functionality, user experience and responsiveness.
        </p>
      </div>

      <div class="card">
        <h3>Quick Information</h3>
        <div class="info-list">
          <div><span>Name</span><strong>Maria Kelvin R.</strong></div>
          <div><span>Field</span><strong>Engineering / Computer Technology</strong></div>
          <div><span>Interests</span><strong>Web Development, AI, Databases</strong></div>
          <div><span>Location</span><strong>Chennai, Tamil Nadu</strong></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="skills">
  <div class="container">
    <div class="section-heading">
      <span>SKILLS</span>
      <h2>Technologies I work with</h2>
    </div>

    <div class="card skills">
      <span>HTML5</span>
      <span>CSS3</span>
      <span>JavaScript</span>
      <span>React</span>
      <span>Python</span>
      <span>Java</span>
      <span>PHP</span>
      <span>SQL</span>
      <span>MySQL</span>
      <span>PostgreSQL</span>
      <span>Supabase</span>
      <span>Git</span>
      <span>GitHub</span>
      <span>Streamlit</span>
      <span>REST APIs</span>
      <span>Responsive Design</span>
    </div>
  </div>
</section>

<section id="projects">
  <div class="container">
    <div class="section-heading">
      <span>PROJECTS</span>
      <h2>Selected work</h2>
      <p>Academic and practical projects demonstrating development and problem-solving skills.</p>
    </div>

    <div class="projects">
      <article class="project card">
        <div class="project-icon">FL</div>
        <h3>FarmLink</h3>
        <p>
          A market-linkage platform connecting farmers and buyers with crop
          listings, price discovery, demand matching and logistics support.
        </p>
        <small>HTML • CSS • JavaScript • Supabase</small>
      </article>

      <article class="project card">
        <div class="project-icon">DB</div>
        <h3>Database Projects</h3>
        <p>
          Database-driven academic applications using SQL, relational design,
          CRUD operations and backend connectivity.
        </p>
        <small>Java • JDBC • MySQL • PostgreSQL</small>
      </article>

      <article class="project card">
        <div class="project-icon">AI</div>
        <h3>AI & Web Experiments</h3>
        <p>
          Practical experiments combining APIs, AI-assisted features and
          responsive interfaces to solve user-focused problems.
        </p>
        <small>Python • APIs • JavaScript • AI</small>
      </article>
    </div>
  </div>
</section>

<section id="education">
  <div class="container">
    <div class="section-heading">
      <span>EDUCATION</span>
      <h2>Academic journey</h2>
    </div>

    <div class="card education">
      <div>
        <h3>Engineering</h3>
        <p>Kamaraj Engineering — Student</p>
        <p>Developing skills in software engineering, DBMS, OOPS, AI and web technologies.</p>
      </div>

      <div>
        <h3>Continuous Learning</h3>
        <p>Projects, hackathons and technical practice</p>
        <p>Learning through implementation, experimentation and building real applications.</p>
      </div>
    </div>
  </div>
</section>

<section class="contact-section" id="contact">
  <div class="container">
    <div class="section-heading contact-heading">
      <span>CONTACT</span>
      <h2>Let's Connect</h2>
      <p>Send me a message. Your details will be stored in the MySQL database.</p>
    </div>

    <?php if ($status === 'success'): ?>
      <div class="message success">✓ Message submitted successfully!</div>
    <?php elseif ($status === 'empty'): ?>
      <div class="message error">Please fill in all fields.</div>
    <?php elseif ($status === 'invalid_email'): ?>
      <div class="message error">Please enter a valid email address.</div>
    <?php elseif ($status === 'error'): ?>
      <div class="message error">Something went wrong. Please try again.</div>
    <?php endif; ?>

    <div class="contact-grid">
      <form action="contact.php" method="POST" class="contact-form">

        <div class="form-row">
          <div>
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name" maxlength="100" required placeholder="Enter your name">
          </div>

          <div>
            <label for="email">Your Email</label>
            <input type="email" id="email" name="email" maxlength="255" required placeholder="Enter your email">
          </div>
        </div>

        <div>
          <label for="subject">Subject</label>
          <input type="text" id="subject" name="subject" maxlength="150" required placeholder="Enter subject">
        </div>

        <div>
          <label for="message">Message</label>
          <textarea id="message" name="message" maxlength="2000" required placeholder="Write your message..."></textarea>
        </div>

        <button type="submit" class="btn primary">Send Message</button>
      </form>

      <div class="contact-info">
        <h3>Get in touch</h3>
        <p>If you prefer email, you can contact me directly.</p>

        <a href="mailto:rjmkelvin@gamil.com" class="email-box">
          <small>Email</small>
          rjmkelvin@gamil.com
        </a>

        <a href="https://github.com/" target="_blank" class="email-box">
          <small>GitHub</small>
          github.com
        </a>

        <a href="https://www.linkedin.com/" target="_blank" class="email-box">
          <small>LinkedIn</small>
          linkedin.com
        </a>
      </div>
    </div>
  </div>
</section>

</main>

<footer>
  © 2026 Maria Kelvin R. • Student Developer Portfolio
</footer>

<script src="js/script.js"></script>
</body>
</html>
