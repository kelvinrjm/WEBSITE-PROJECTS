MARIA KELVIN R. - PHP + XAMPP PORTFOLIO
==========================================

TECHNOLOGY
----------
Frontend: HTML, CSS, JavaScript
Backend: PHP
Database: MySQL
Server: XAMPP / Apache

FOLDER
------
Copy the entire "kelvin_portfolio_php" folder to:

C:\xampp\htdocs\portfolio

Then open:

http://localhost/portfolio/

SETUP
-----
1. Open XAMPP Control Panel.
2. Start Apache.
3. Start MySQL.
4. Open:
   http://localhost/phpmyadmin/
5. Click SQL.
6. Copy the contents of:
   database/portfolio.sql
7. Run the SQL.
8. Open:
   http://localhost/portfolio/

CONTACT FORM
------------
The portfolio is a single-page website.

When a visitor submits:
- Name
- Email
- Subject
- Message

PHP receives the form in contact.php and stores it in:

portfolio_db
  |
  +-- contact_messages

You can view submitted messages in phpMyAdmin.

EMAIL
-----
Your email is:

rjmkelvin@gamil.com

The email address in the portfolio uses mailto:
so visitors can click it to open their email application.

IMPORTANT:
The database storage works through XAMPP immediately.

The optional PHP mail() notification is included in contact.php,
but actual outgoing email from localhost requires SMTP/PHP mail
configuration in XAMPP.

If you only need the assignment requirement "store sender details",
you do not need SMTP configuration.

FILES
-----
index.php       -> Single-page portfolio
contact.php     -> Handles submitted contact form
db.php          -> MySQL connection
css/style.css   -> Responsive design
js/script.js    -> Mobile navigation
database/portfolio.sql -> Database/table creation

DO NOT OPEN PHP BY DOUBLE CLICKING
----------------------------------
Do NOT use:

file:///C:/xampp/htdocs/portfolio/index.php

Use:

http://localhost/portfolio/

because Apache must execute the PHP code.

IF MYSQL CONNECTION FAILS
-------------------------
Check that MySQL is running in XAMPP.

Default local settings used by db.php:

Host: localhost
Username: root
Password: empty
Database: portfolio_db
